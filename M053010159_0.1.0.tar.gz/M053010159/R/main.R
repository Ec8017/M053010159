#' Illustrative Function for Factorial
#' Data date missing fill
#' @param data
#' @param interval Ouput interval
#' @return
#' @export
#'
#' @examples
#' rm(list=ls())
#' setwd("set Path")
#' data=read.csv("input.csv",header=T,sep=",")
#' Miss_Freq(data,1)

Miss_Freq=function(data,interval)

{


  第一天=as.numeric(data$日期[1])
  最末天=as.numeric(data$日期[nrow(data)])


  完整日期=c()

  dd=1

  date_range=as.numeric(gsub("-",replacement="",as.character(Sys.Date())))

  while(date_range>最末天)
  {
    date_range=as.numeric(gsub("-",replacement="",as.character(Sys.Date()-dd)))
    dd=dd+1
  }


  d=-1

  while(date_range>第一天)
  {
    date_range=as.numeric(gsub("-",replacement="",as.character(Sys.Date()-(d+dd))))
    完整日期=c(完整日期,date_range)
    d=d+1
  }



  complete_name=c("日期","時","分","秒")

  #檢查欄位

  check=c(0,0,0,0,1)   #第5個是資料欄

  for(i in 1:4)
  {
    if (names(data)[i]==complete_name[i]) {check[i]=1}
  }

  最小單位=names(data)[length( names(data))-1]


  #==================================建立完整表格 (若最小單位為秒，則1秒1筆；若最小單位為分，則1分1筆)

  complete_input=cbind(rep(完整日期,each=86400),rep(0:23,each=3600),rep(rep(0:59,each=60),24),rep(0:59,1440),NA)

  complete=unique(complete_input[,-which(check==0)])

  colnames(complete)=colnames(data)


  repeat_data=rbind(data,complete)


  #依照時刻排序


  if(check[4]==1) {repeat_data=repeat_data[order(repeat_data$秒),]}   #秒排序

  if(check[3]==1) {repeat_data=repeat_data[order(repeat_data$分),]}   #分排序

  if(check[2]==1) {repeat_data=repeat_data[order(repeat_data$時),]}   #時排序

  if(check[1]==1) {repeat_data=repeat_data[order(repeat_data$日期),]}   #日期排序



  q=1

  freq=p=0

  #===========================================================尋找缺值時刻



  for (i in 2:nrow(repeat_data))
  {
    if (prod(repeat_data[i,1:(ncol(repeat_data)-1)]==repeat_data[i-1,1:(ncol(repeat_data)-1)])==0)
    {
      p=p+1
    }
    freq=c(freq,p)

    if(100*i/nrow(repeat_data)>q)
    {
      print(paste("尋找缺值時刻，完成",round(100*i/nrow(repeat_data)),"%。",sep=""))
      q=q+1
    }
  }
  print(paste("尋找缺值時刻，完成100%。",sep=""))


  t_data=cbind(repeat_data,freq)

  #===========================================================缺時間之資料補植



  frequence_data=c()

  qq=1

  for (tt in 1:max(freq))
  {
    freq_data=subset(t_data,freq==tt)
    if (nrow(freq_data)==1)
    {
      frequence_data=rbind(frequence_data,freq_data)
    } else
    {
      frequence_data=rbind(frequence_data,subset(freq_data,freq_data[,(ncol(freq_data)-1)]!="NA"))
    }


    if(100*tt/max(freq)>qq)
    {
      print(paste("重複資料刪除中，完成",round(100*tt/max(freq)),"%。",sep=""))
      qq=qq+1
    }

  }
  print(paste("重複資料刪除中，完成100%。",sep=""))

  frequence_data[1:100,]
  #===========================================================指定輸出資料頻率

  eval(parse(text = paste("finall_data=subset(frequence_data,",最小單位,"%%interval==0)",sep="")))


  write.csv(finall_data[,-ncol(freq_data)],paste("output(",interval,最小單位,"一筆).csv",sep=""),row.names=F)

}

